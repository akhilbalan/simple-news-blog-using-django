from django.urls import path

from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
    path('home',views.home,name='home'),
    path('news/',views.news,name='news'),
    path('newslist/',views.newslist,name='newslist'),
    path('categories/',views.categories,name='categories'),
    path('categorylist/',views.categorylist,name='categorylist'),
    path('update_new/<str:pk>/',views.update_new,name='update_new'),
    path('delete_new/<str:pk>/',views.delete_new,name='delete_new'),
    path('update_cat/<str:pk>/',views.update_cat,name='update_cat'),
    path('delete_cat/<str:pk>/',views.delete_cat,name='delete_cat'),
    path('register/',views.register,name='register'),
    path('',views.loginPage,name='loginPage'),
    path('logoutPage/',views.logoutPage,name='logoutPage'),
    path('changepass/', views.user_change_pass, name='changepass')




]