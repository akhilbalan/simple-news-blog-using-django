from asyncio.windows_events import NULL
from pickle import TRUE
from django.db import models
from django.test import tag

# Create your models here.
class Category(models.Model):
    ctitle=models.CharField(max_length=100)

    def __str__(self):
        return self.ctitle


class News(models.Model):
    ntitle=models.CharField(max_length=100)
    content=models.TextField()
    img=models.ImageField(upload_to='media',null=True)
    category=models.ForeignKey(Category, on_delete=models.CASCADE)
    ntag=models.PositiveIntegerField()
