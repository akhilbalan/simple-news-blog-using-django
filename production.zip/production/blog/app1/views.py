from datetime import date
import re
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.http import HttpRequest
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm


from . models import *
from . forms import *




# Create your views here.
@login_required(login_url='loginPage')
def home(request):
    return render(request,'home.html')
@login_required(login_url='loginPage')
def news(request):
    newlist=News.objects.all()
    context={
        'newlist':newlist
    }

    return render(request,'news.html',context)
@login_required(login_url='loginPage')
def newslist(request):
    form=NewsForm()
    if(request.method=='POST'):
        form=NewsForm(request.POST, request.FILES)

        if(form.is_valid()):
            form.save()
            return news(request)
       
    context={
        'form': form,
    }
    return render(request,'newslist.html',context)
@login_required(login_url='loginPage')
def categories(request):
    catlist=Category.objects.all()
    context={
        'catlist':catlist
    }

    return render(request,'categories.html',context)
@login_required(login_url='loginPage')
def categorylist(request):
    form=CategoryForm()
    if(request.method=='POST'):
        form=CategoryForm(request.POST)
        if(form.is_valid()):
            form.save()
            return categories(request)
       
    context={
        'form': form,
    }
    return render(request,'categorylist.html',context)
def update_new(request,pk):
    newlist=News.objects.get(id=pk)
    form=NewsForm(instance=newlist)
    if(request.method=='POST'):
        form=NewsForm(request.POST,instance=newlist)
        if(form.is_valid()):
            form.save()
            return news(request)
       
    context={
        'form': form,
    }
    
    return render(request,'newslist.html',context)
def delete_new(request,pk):
    newlist=News.objects.get(id=pk)
    newlist.delete()
    return news(request)
def update_cat(request,pk):
    catlist=Category.objects.get(id=pk)
    form=CategoryForm(instance=catlist)
    if(request.method=='POST'):
        form=CategoryForm(request.POST,instance=catlist)
        if(form.is_valid()):
            form.save()
            return categories(request)
       
    context={
        'form': form,
    }
    
    return render(request,'categorylist.html',context)
def delete_cat(request,pk):
    catlist=Category.objects.get(id=pk)
    catlist.delete()
    return categories(request)


def register(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form=CreateUserForm()

        if request.method=='POST':
            form=CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user=form.cleaned_data.get('username')
                messages.success(request, "Account was created for "+user)
                return redirect('loginPage')

        context={
            'form': form,

        }
        return render(request, 'register.html',context)


def loginPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method == 'POST':
            username=request.POST.get('username')
            password=request.POST.get('password')

            user=authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.info(request, "Username or Password is incorrect")
                
        context={
        }
        return render(request, 'loginPage.html',context)

def logoutPage(request):
    logout(request)
    return redirect('loginPage')
def user_change_pass(request):
    if request.method == 'POST':
        form=PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form=PasswordChangeForm(user=request.user)
    return render(request, 'changepass.html', {'form':form})

